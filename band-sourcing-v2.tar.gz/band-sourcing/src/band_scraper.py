"""
Band 게시글 웹 스크래퍼 (Playwright 기반).

band_fetcher.py의 드롭인 교체 모듈.
Band Open API 승인 없이 웹 크롤링으로 동일한 데이터를 수집한다.

인터페이스:
  - get_band_keys(target_names) -> dict[str, str]
  - fetch_all_posts(band_key) -> list[dict]
  - close()

반환 포스트 형식 (main.py 호환):
  {
    "post_key": str,
    "created_at": int (ms timestamp),
    "content": str,
    "photos": [{"url": str}],
  }
"""

import hashlib
import json
import logging
import os
import re
import time
from datetime import datetime
from pathlib import Path

from playwright.sync_api import sync_playwright, Browser, Page, BrowserContext

logger = logging.getLogger(__name__)

BAND_HOME = "https://band.us"
BAND_LOGIN = "https://auth.band.us/login_page"


class BandScraper:
    """Playwright 기반 밴드 스크래퍼. BandFetcher와 동일 인터페이스."""

    def __init__(
        self,
        naver_id: str,
        naver_pw: str,
        cutoff_date: str,
        headless: bool = True,
        session_path: str = "data/band_session.json",
    ):
        self.naver_id = naver_id
        self.naver_pw = naver_pw
        self.cutoff = datetime.strptime(cutoff_date, "%Y-%m-%d")
        self.headless = headless
        self.session_path = session_path

        self._pw = sync_playwright().start()
        self._browser: Browser = self._pw.chromium.launch(
            headless=headless,
            args=["--no-sandbox", "--disable-setuid-sandbox"],
        )
        self._context: BrowserContext | None = None
        self._page: Page | None = None
        self._logged_in = False

    # ── 세션 관리 ──

    def _save_session(self):
        """쿠키를 파일에 저장하여 재로그인 방지."""
        if self._context:
            cookies = self._context.cookies()
            os.makedirs(os.path.dirname(self.session_path), exist_ok=True)
            with open(self.session_path, "w", encoding="utf-8") as f:
                json.dump(cookies, f, ensure_ascii=False)
            logger.info(f"세션 저장 완료: {self.session_path}")

    def _load_session(self) -> bool:
        """저장된 세션 쿠키 로드. 성공 시 True."""
        if not os.path.exists(self.session_path):
            return False
        try:
            with open(self.session_path, "r", encoding="utf-8") as f:
                cookies = json.load(f)
            self._context = self._browser.new_context(
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/131.0.0.0 Safari/537.36"
                ),
                viewport={"width": 1280, "height": 800},
            )
            self._context.add_cookies(cookies)
            self._page = self._context.new_page()
            logger.info("저장된 세션 로드 완료")
            return True
        except Exception as e:
            logger.warning(f"세션 로드 실패: {e}")
            return False

    def _is_session_valid(self) -> bool:
        """현재 세션이 유효한지 확인."""
        try:
            self._page.goto(f"{BAND_HOME}/feed", wait_until="domcontentloaded", timeout=15000)
            time.sleep(2)
            url = self._page.url
            if "auth.band.us" in url or "login" in url:
                return False
            return True
        except Exception:
            return False

    # ── 로그인 ──

    def _login_naver(self):
        """네이버 계정으로 밴드 로그인."""
        logger.info("네이버 계정으로 밴드 로그인 시작...")

        self._context = self._browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1280, "height": 800},
        )
        self._page = self._context.new_page()

        # Band 로그인 페이지
        self._page.goto(BAND_LOGIN, wait_until="domcontentloaded", timeout=30000)
        time.sleep(2)

        # 네이버 로그인 버튼 클릭
        naver_btn = self._page.locator('a.-naver, button.-naver, [class*="naver"]').first
        if naver_btn.count() == 0:
            # 대체 셀렉터
            naver_btn = self._page.locator('a[href*="naver"], button:has-text("네이버")')
        naver_btn.first.click()
        time.sleep(3)

        # 네이버 로그인 폼
        current_url = self._page.url
        if "nid.naver.com" in current_url:
            # ID 입력
            id_input = self._page.locator('input#id, input[name="id"]').first
            id_input.fill("")
            # 붙여넣기 방식으로 입력 (자동입력 감지 우회)
            self._page.evaluate(
                f'document.querySelector("input#id, input[name=\\"id\\"]").value = "{self.naver_id}"'
            )
            id_input.dispatch_event("input")
            time.sleep(0.5)

            # PW 입력
            pw_input = self._page.locator('input#pw, input[name="pw"]').first
            pw_input.fill("")
            self._page.evaluate(
                f'document.querySelector("input#pw, input[name=\\"pw\\"]").value = "{self.naver_pw}"'
            )
            pw_input.dispatch_event("input")
            time.sleep(0.5)

            # 로그인 버튼
            login_btn = self._page.locator(
                'button#log\\.login, button[type="submit"], input[type="submit"]'
            ).first
            login_btn.click()
            time.sleep(5)

        # 로그인 후 Band 피드로 리다이렉트 대기
        for _ in range(30):
            if "band.us" in self._page.url and "auth" not in self._page.url:
                break
            time.sleep(1)

        if "auth" in self._page.url or "login" in self._page.url:
            raise Exception(
                "밴드 로그인 실패 - 수동 로그인이 필요할 수 있습니다 "
                "(2단계 인증 / 캡차 등)"
            )

        self._logged_in = True
        self._save_session()
        logger.info("밴드 로그인 성공!")

    def ensure_logged_in(self):
        """로그인 상태 보장."""
        if self._logged_in:
            return

        # 1) 저장된 세션 시도
        if self._load_session() and self._is_session_valid():
            self._logged_in = True
            logger.info("저장된 세션으로 로그인 확인됨")
            return

        # 2) 새로 로그인
        self._login_naver()

    # ── 밴드 검색 (get_band_keys 호환) ──

    def get_band_keys(self, target_names: list[str]) -> dict[str, str]:
        """
        가입된 밴드 목록에서 target_names에 해당하는 밴드의 URL key를 추출.
        반환: {"잡화천국22": "band_url_key", ...}
        """
        self.ensure_logged_in()

        result = {}
        self._page.goto(f"{BAND_HOME}/feed", wait_until="domcontentloaded", timeout=30000)
        time.sleep(3)

        # 밴드 목록 사이드바 또는 밴드 탐색
        for band_name in target_names:
            try:
                band_key = self._find_band_key(band_name)
                if band_key:
                    result[band_name] = band_key
                    logger.info(f"밴드 발견: {band_name} -> {band_key}")
                else:
                    logger.warning(f"밴드를 찾을 수 없음: {band_name}")
            except Exception as e:
                logger.error(f"밴드 검색 실패 ({band_name}): {e}")

        return result

    def _find_band_key(self, band_name: str) -> str | None:
        """밴드 이름으로 검색하여 band_key(URL path)를 찾는다."""
        # 내 밴드 목록 페이지
        self._page.goto(f"{BAND_HOME}/feed", wait_until="domcontentloaded", timeout=30000)
        time.sleep(2)

        # 사이드바에서 밴드 링크 찾기
        band_links = self._page.locator('a[href*="/band/"]')
        count = band_links.count()

        for i in range(count):
            link = band_links.nth(i)
            text = link.inner_text().strip()
            href = link.get_attribute("href") or ""

            if band_name in text:
                # /band/12345678 형태에서 key 추출
                m = re.search(r'/band/(\d+)', href)
                if m:
                    return m.group(1)

        # 사이드바에서 못 찾으면 검색 시도
        logger.info(f"사이드바에서 {band_name} 못 찾음 -> 직접 밴드 페이지 탐색")

        # 대체: 모든 밴드 목록 페이지
        self._page.goto(f"{BAND_HOME}/my_bands", wait_until="domcontentloaded", timeout=30000)
        time.sleep(3)

        band_links = self._page.locator('a[href*="/band/"]')
        count = band_links.count()

        for i in range(count):
            link = band_links.nth(i)
            text = link.inner_text().strip()
            href = link.get_attribute("href") or ""

            if band_name in text:
                m = re.search(r'/band/(\d+)', href)
                if m:
                    return m.group(1)

        return None

    # ── 게시글 수집 (fetch_all_posts 호환) ──

    def fetch_all_posts(self, band_key: str) -> list[dict]:
        """
        밴드의 게시글을 스크롤하면서 수집.
        cutoff_date 이전 게시글이 나오면 중단.

        반환 형식 (main.py 호환):
        [
          {
            "post_key": "unique_id",
            "created_at": 1234567890000,  # ms timestamp
            "content": "게시글 텍스트",
            "photos": [{"url": "https://..."}],
          },
          ...
        ]
        """
        self.ensure_logged_in()

        band_url = f"{BAND_HOME}/band/{band_key}"
        self._page.goto(band_url, wait_until="domcontentloaded", timeout=30000)
        time.sleep(3)

        all_posts = []
        seen_keys = set()
        no_new_count = 0
        max_scroll_attempts = 100

        for scroll_attempt in range(max_scroll_attempts):
            # 현재 화면의 게시글 파싱
            post_elements = self._page.locator(
                '[class*="postWrap"], [class*="post_wrap"], '
                '[data-viewname*="post"], article[class*="post"]'
            )
            current_count = post_elements.count()

            new_found = False
            stop_scrolling = False

            for i in range(current_count):
                try:
                    post_el = post_elements.nth(i)
                    post_data = self._parse_post_element(post_el, band_key)

                    if not post_data:
                        continue

                    if post_data["post_key"] in seen_keys:
                        continue

                    # cutoff 체크
                    created = datetime.fromtimestamp(post_data["created_at"] / 1000)
                    if created < self.cutoff:
                        stop_scrolling = True
                        break

                    seen_keys.add(post_data["post_key"])
                    all_posts.append(post_data)
                    new_found = True

                except Exception as e:
                    logger.debug(f"게시글 파싱 실패 (index {i}): {e}")
                    continue

            if stop_scrolling:
                logger.info(f"cutoff 날짜 도달 (scroll #{scroll_attempt})")
                break

            if not new_found:
                no_new_count += 1
                if no_new_count >= 5:
                    logger.info("더 이상 새 게시글 없음 -> 스크롤 중단")
                    break
            else:
                no_new_count = 0

            # 스크롤 다운
            self._page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            time.sleep(2)

        logger.info(f"밴드 {band_key}: 총 {len(all_posts)}개 게시글 수집")
        return all_posts

    def _parse_post_element(self, el, band_key: str) -> dict | None:
        """단일 게시글 DOM 요소에서 데이터 추출."""
        try:
            # 게시글 ID (data-post-id 또는 href에서 추출)
            post_key = self._extract_post_key(el)
            if not post_key:
                return None

            # 게시글 텍스트
            content = self._extract_content(el)
            if not content:
                return None

            # 작성 시간
            created_at = self._extract_timestamp(el)
            if not created_at:
                return None

            # 이미지
            photos = self._extract_photos(el)

            return {
                "post_key": f"{band_key}_{post_key}",
                "created_at": created_at,
                "content": content,
                "photos": photos,
            }

        except Exception as e:
            logger.debug(f"게시글 파싱 에러: {e}")
            return None

    def _extract_post_key(self, el) -> str | None:
        """게시글 고유 키 추출."""
        # data 속성에서 추출
        for attr in ["data-post-id", "data-postid", "data-post_key"]:
            val = el.get_attribute(attr)
            if val:
                return val

        # 링크에서 추출
        link = el.locator('a[href*="/post/"]').first
        if link.count() > 0:
            href = link.get_attribute("href") or ""
            m = re.search(r'/post/([^/?]+)', href)
            if m:
                return m.group(1)

        # content 해시로 대체
        content = el.inner_text()[:200]
        if content.strip():
            return hashlib.md5(content.encode()).hexdigest()[:16]

        return None

    def _extract_content(self, el) -> str:
        """게시글 본문 텍스트 추출."""
        # 본문 영역 셀렉터들
        selectors = [
            '[class*="postText"]',
            '[class*="post_text"]',
            '[class*="postBody"]',
            '[class*="post_body"]',
            '[class*="txtBody"]',
            '[class*="txt_body"]',
            '.postContent',
            '.post_content',
            'p[class*="text"]',
        ]

        for sel in selectors:
            text_el = el.locator(sel).first
            if text_el.count() > 0:
                text = text_el.inner_text().strip()
                if text and len(text) > 5:
                    return text

        # fallback: 전체 텍스트에서 추출 (노이즈 있을 수 있음)
        full_text = el.inner_text().strip()
        if full_text and len(full_text) > 10:
            return full_text

        return ""

    def _extract_timestamp(self, el) -> int | None:
        """게시글 작성 시간을 ms timestamp로 추출."""
        # time 태그
        time_el = el.locator("time").first
        if time_el.count() > 0:
            dt_attr = time_el.get_attribute("datetime")
            if dt_attr:
                try:
                    dt = datetime.fromisoformat(dt_attr.replace("Z", "+00:00"))
                    return int(dt.timestamp() * 1000)
                except Exception:
                    pass

        # data 속성
        for attr in ["data-created-at", "data-timestamp", "data-time"]:
            val = el.get_attribute(attr)
            if val and val.isdigit():
                ts = int(val)
                if ts > 1e12:  # already ms
                    return ts
                return ts * 1000

        # 날짜 텍스트 파싱
        date_selectors = [
            '[class*="date"]',
            '[class*="time"]',
            '[class*="ago"]',
            'span[class*="post_time"]',
        ]
        for sel in date_selectors:
            date_el = el.locator(sel).first
            if date_el.count() > 0:
                date_text = date_el.inner_text().strip()
                ts = self._parse_date_text(date_text)
                if ts:
                    return ts

        return None

    def _parse_date_text(self, text: str) -> int | None:
        """한국어 날짜 텍스트를 ms timestamp로 변환."""
        # "2026년 3월 15일" 패턴
        m = re.search(r'(\d{4})년\s*(\d{1,2})월\s*(\d{1,2})일', text)
        if m:
            try:
                dt = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
                return int(dt.timestamp() * 1000)
            except Exception:
                pass

        # "3월 15일" 패턴 (올해)
        m = re.search(r'(\d{1,2})월\s*(\d{1,2})일', text)
        if m:
            try:
                dt = datetime(datetime.now().year, int(m.group(1)), int(m.group(2)))
                return int(dt.timestamp() * 1000)
            except Exception:
                pass

        # "N시간 전" / "N분 전" / "N일 전"
        m = re.search(r'(\d+)\s*시간\s*전', text)
        if m:
            hours = int(m.group(1))
            ts = int((time.time() - hours * 3600) * 1000)
            return ts

        m = re.search(r'(\d+)\s*분\s*전', text)
        if m:
            mins = int(m.group(1))
            ts = int((time.time() - mins * 60) * 1000)
            return ts

        m = re.search(r'(\d+)\s*일\s*전', text)
        if m:
            days = int(m.group(1))
            ts = int((time.time() - days * 86400) * 1000)
            return ts

        # "어제"
        if "어제" in text:
            return int((time.time() - 86400) * 1000)

        return None

    def _extract_photos(self, el) -> list[dict]:
        """게시글 이미지 URL 추출."""
        photos = []
        seen_urls = set()

        img_elements = el.locator("img")
        count = img_elements.count()

        for i in range(count):
            img = img_elements.nth(i)
            src = img.get_attribute("src") or img.get_attribute("data-src") or ""

            # 프로필/아이콘/이모지 이미지 제외
            if not src:
                continue
            if any(skip in src.lower() for skip in [
                "profile", "avatar", "icon", "emoji", "static",
                "banner", "logo", "thumb_small", "1x1"
            ]):
                continue

            # 밴드 이미지 CDN URL만 수집
            if "band" not in src and "phinf" not in src and "dthumb" not in src:
                # 외부 이미지도 포함 (상품 이미지일 수 있음)
                if not src.startswith("http"):
                    continue

            # 중복 제거
            if src in seen_urls:
                continue
            seen_urls.add(src)

            # 최대 해상도로 변환
            clean_url = self._get_full_res_url(src)
            photos.append({"url": clean_url})

        return photos

    @staticmethod
    def _get_full_res_url(url: str) -> str:
        """밴드 이미지 URL을 최대 해상도로 변환."""
        # /xx_yy/ 사이즈 파라미터 제거
        url = re.sub(r'/\d+x\d+/', '/', url)
        # type=optimize 등 파라미터 제거
        url = re.sub(r'[?&]type=[^&]+', '', url)
        return url

    # ── 정리 ──

    def close(self):
        """브라우저 종료."""
        try:
            if self._page:
                self._page.close()
            if self._context:
                self._context.close()
            if self._browser:
                self._browser.close()
            if self._pw:
                self._pw.stop()
        except Exception as e:
            logger.debug(f"close 에러 (무시): {e}")


if __name__ == "__main__":
    print("band_scraper.py 로드 성공!")
    print("실제 테스트: python -c 'from src.band_scraper import BandScraper; print(\"OK\")'")
