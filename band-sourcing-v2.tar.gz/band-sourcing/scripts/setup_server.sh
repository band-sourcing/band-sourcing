#!/bin/bash
# ============================================
# band-sourcing 서버 셋업 스크립트
# Vultr 서버: 158.247.247.171
# ============================================
set -e

echo "=== 1/5: 시스템 패키지 업데이트 ==="
apt-get update -y
apt-get install -y python3 python3-pip python3-venv git

echo "=== 2/5: 프로젝트 클론 (또는 업데이트) ==="
PROJECT_DIR="/opt/band-sourcing"
if [ -d "$PROJECT_DIR" ]; then
    cd "$PROJECT_DIR"
    git pull origin main
else
    git clone https://github.com/LordOfWins/band-sourcing.git "$PROJECT_DIR"
    cd "$PROJECT_DIR"
fi

echo "=== 3/5: Python 가상환경 + 의존성 설치 ==="
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "=== 4/5: Playwright 브라우저 설치 ==="
playwright install chromium
playwright install-deps chromium

echo "=== 5/5: 디렉토리 생성 ==="
mkdir -p data logs

echo ""
echo "========================================="
echo "셋업 완료!"
echo ""
echo "다음 단계:"
echo "  1) .env 파일 생성:"
echo "     cp .env.example .env"
echo "     nano .env  (NAVER_ID, NAVER_PW, WC 키 입력)"
echo ""
echo "  2) DB 초기화:"
echo "     source venv/bin/activate"
echo "     python scripts/init_db.py"
echo ""
echo "  3) 테스트 실행:"
echo "     python main.py"
echo ""
echo "  4) 크론잡 등록 (새벽 4시):"
echo "     crontab -e"
echo "     0 4 * * * cd /opt/band-sourcing && source venv/bin/activate && bash run.sh"
echo "========================================="
